# PharmaGuard Login System - Setup Guide

## Overview
This document explains the complete login system implementation for PharmaGuard, including backend authentication and frontend user management.

## Architecture

### Backend (Flask)
- **Authentication Module** (`backend/auth.py`): Handles JWT tokens, user registration, and login
- **JWT Tokens**: Secure token-based authentication
- **Protected Routes**: The `/api/analyze` endpoint now requires authentication

### Frontend (Next.js)
- **Auth Context** (`app/auth-context.tsx`): Global state management for authentication
- **Login Page** (`app/login/page.tsx`): User login interface
- **Register Page** (`app/register/page.tsx`): User registration interface
- **Dashboard** (`app/dashboard/page.tsx`): Protected main application (formerly homepage)

## File Structure

```
app/
├── auth-context.tsx          # Auth state provider
├── page.tsx                  # Home (redirects to login/dashboard)
├── layout.tsx                # Root layout with AuthProvider
├── login/
│   └── page.tsx             # Login page
├── register/
│   └── page.tsx             # Register page
└── dashboard/
    └── page.tsx             # Protected dashboard

backend/
├── auth.py                  # Authentication utilities
└── app.py                   # Updated with auth endpoints
```

## Setup Instructions

### 1. Install Dependencies

**Backend:**
```bash
cd backend
pip install -r requirements.txt
```

**Frontend:**
```bash
npm install
```

### 2. Configure Environment Variables

Create a `.env.local` file in the root directory:
```env
NEXT_PUBLIC_BACKEND_URL=http://localhost:5000
```

Optionally, create `.env` in the backend directory:
```env
JWT_SECRET=your-secret-key-change-in-production
```

### 3. Start the Application

**Terminal 1 - Backend:**
```bash
cd backend
python app.py
```

**Terminal 2 - Frontend:**
```bash
npm run dev
```

The app will be available at `http://localhost:3000`

## API Endpoints

### Authentication Endpoints

#### Register User
- **POST** `/api/auth/register`
- **Body:**
  ```json
  {
    "email": "user@example.com",
    "password": "password123"
  }
  ```
- **Response:**
  ```json
  {
    "success": true,
    "message": "User registered successfully",
    "token": "jwt_token_here",
    "user": { "email": "user@example.com" }
  }
  ```

#### Login User
- **POST** `/api/auth/login`
- **Body:**
  ```json
  {
    "email": "user@example.com",
    "password": "password123"
  }
  ```
- **Response:**
  ```json
  {
    "success": true,
    "message": "Login successful",
    "token": "jwt_token_here",
    "user": { "email": "user@example.com" }
  }
  ```

#### Verify Token
- **POST** `/api/auth/verify`
- **Body:**
  ```json
  {
    "token": "jwt_token_here"
  }
  ```
- **Response:**
  ```json
  {
    "success": true,
    "user": { "email": "user@example.com" }
  }
  ```

### Protected Endpoints

#### Analyze (Protected)
- **POST** `/api/analyze`
- **Headers:**
  ```
  Authorization: Bearer <jwt_token>
  ```
- **Body:** FormData with vcf_file and drugs
- **Response:** Analysis results

## User Flow

1. **Landing Page**: User visits `/` and is redirected based on auth status
   - If authenticated → `/dashboard`
   - If not authenticated → `/login`

2. **Login/Register**: 
   - New users visit `/register` to create account
   - Existing users visit `/login`
   - Credentials stored in mock database (in production, use real database)

3. **Dashboard**: 
   - Protected route requiring valid JWT token
   - User can upload VCF files and analyze drugs
   - Logout button to clear session

4. **Token Management**:
   - Token stored in localStorage
   - Automatically sent with analysis requests
   - Expires after 24 hours (configurable)

## Security Features

- **Password Hashing**: Werkzeug's `generate_password_hash` for secure storage
- **JWT Tokens**: 24-hour expiration (configurable)
- **CORS Enabled**: Cross-origin requests allowed
- **Token Validation**: Required for protected routes

## Demo Credentials

For testing purposes, the login page displays:
- **Email**: demo@example.com
- **Password**: password123

You can register new accounts through the `/register` page.

## Customization

### Change JWT Expiration
Edit `backend/auth.py`:
```python
JWT_EXPIRATION = 24  # Change to desired hours
```

### Use Real Database
Replace the mock `users_db` dictionary in `backend/auth.py` with:
- SQLAlchemy with PostgreSQL
- MongoDB
- Firebase Authentication

### Styling
All pages use Tailwind CSS. Modify colors in:
- `app/globals.css`
- Inline `className` props in React components

### Branding
Update text in:
- Login/Register pages
- Dashboard navigation
- Layout metadata

## Troubleshooting

### Backend Won't Start
```bash
# Check if port 5000 is available
lsof -i :5000  # macOS/Linux
netstat -ano | findstr :5000  # Windows

# If in use, kill process or change port in app.py
```

### CORS Errors
- Ensure `NEXT_PUBLIC_BACKEND_URL` env var is set
- Verify Flask backend has CORS enabled: `CORS(app)`

### Token Errors
- Clear localStorage: `localStorage.clear()`
- Refresh page to re-authenticate
- Check JWT_SECRET is consistent between requests

## Production Checklist

- [ ] Replace mock user database with real database
- [ ] Change `JWT_SECRET` to secure random key
- [ ] Enable HTTPS
- [ ] Add rate limiting to auth endpoints
- [ ] Implement password reset flow
- [ ] Add email verification
- [ ] Add refresh tokens
- [ ] Configure CORS origins whitelist
- [ ] Add logging and monitoring
- [ ] Set `debug=False` in Flask production

## Next Steps

1. **Database Integration**: Replace `users_db` with real database
2. **Email Verification**: Verify emails during registration
3. **Password Reset**: Implement forgot password flow
4. **Social Login**: Add Google, GitHub authentication
5. **2FA**: Implement two-factor authentication
6. **User Profile**: Add user profile management
7. **API Analytics**: Track analysis usage per user
