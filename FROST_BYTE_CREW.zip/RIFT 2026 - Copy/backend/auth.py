"""
Authentication module for PharmaGuard
Handles user registration, login, and JWT token management
"""
from flask import jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask import request
import jwt
import os
from datetime import datetime, timedelta

# Mock user database (in production, use a real database)
users_db = {}
JWT_SECRET = os.getenv('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_EXPIRATION = 24  # hours

def register_user(email, password):
    """
    Register a new user
    Returns: (success: bool, message: str, token: str or None)
    """
    if email in users_db:
        return False, "User already exists", None
    
    if len(password) < 6:
        return False, "Password must be at least 6 characters", None
    
    hashed_password = generate_password_hash(password)
    users_db[email] = {
        'password': hashed_password,
        'created_at': datetime.now().isoformat()
    }
    
    # Generate JWT token
    token = generate_token(email)
    return True, "User registered successfully", token

def login_user(email, password):
    """
    Authenticate user and return JWT token
    Returns: (success: bool, message: str, token: str or None)
    """
    if email not in users_db:
        return False, "Invalid email or password", None
    
    user = users_db[email]
    if not check_password_hash(user['password'], password):
        return False, "Invalid email or password", None
    
    token = generate_token(email)
    return True, "Login successful", token

def generate_token(email):
    """Generate JWT token for user"""
    payload = {
        'email': email,
        'iat': datetime.utcnow(),
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
    return token

def verify_token(token):
    """
    Verify JWT token and return email
    Returns: (success: bool, email: str or None)
    """
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return True, payload['email']
    except jwt.ExpiredSignatureError:
        return False, None
    except jwt.InvalidTokenError:
        return False, None

def token_required(f):
    """Decorator to require valid JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Check for token in headers
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]
            except IndexError:
                return jsonify({'error': 'Invalid token format'}), 401
        
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        success, email = verify_token(token)
        if not success:
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        return f(email, *args, **kwargs)
    
    return decorated
