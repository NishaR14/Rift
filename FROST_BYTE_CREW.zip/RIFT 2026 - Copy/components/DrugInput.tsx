'use client'

import React from 'react'

interface DrugInputProps {
  value: string
  onChange: (value: string) => void
}

const SUPPORTED_DRUGS = [
  'CODEINE',
  'WARFARIN',
  'CLOPIDOGREL',
  'SIMVASTATIN',
  'AZATHIOPRINE',
  'FLUOROURACIL',
]

export default function DrugInput({ value, onChange }: DrugInputProps) {
  const [inputText, setInputText] = React.useState(value)
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    setInputText(value)
  }, [value])

  const normalize = (arr: string[]) =>
    arr.map((d) => d.trim()).filter(Boolean).map((d) => d.toUpperCase())

  const emitChange = (arr: string[]) => {
    const normalized = normalize(arr)
    onChange(normalized.join(', '))
  }

  const handleDrugClick = (drug: string) => {
    const current = normalize(inputText.split(','))
    if (current.includes(drug)) {
      const next = current.filter((d) => d !== drug)
      setInputText(next.join(', '))
      emitChange(next)
      setError(null)
    } else {
      const next = [...current, drug]
      setInputText(next.join(', '))
      emitChange(next)
      setError(null)
    }
  }

  const handleInputChange = (text: string) => {
    setInputText(text)
    setError(null)
  }

  const applyInput = () => {
    const entries = normalize(inputText.split(','))
    const invalid = entries.filter((d) => !SUPPORTED_DRUGS.includes(d))
    if (invalid.length > 0) {
      setError(`Invalid drug name(s): ${invalid.join(', ')}`)
      return
    }
    setError(null)
    emitChange(entries)
  }

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const options = Array.from(e.target.selectedOptions).map((o) => o.value)
    setInputText(options.join(', '))
    emitChange(options)
    setError(null)
  }

  return (
    <div>
      <label className="block text-sm font-semibold text-white mb-1">Drug Name(s)</label>
      <p className="text-xs text-green-200 mb-3">Select the drug (click chips for single or multiple selection)</p>

      <div>
        <input
          type="text"
          value={inputText}
          onChange={(e) => handleInputChange(e.target.value)}
          onBlur={applyInput}
          placeholder="Select the drug or type to add (comma-separated)"
          className="w-full px-4 py-3 bg-white/10 border border-green-400/30 rounded-lg text-white placeholder-green-300/50 focus:ring-2 focus:ring-green-400 focus:border-transparent outline-none"
        />
      </div>

      {/* Single unified control: quick-select chips support single & multi selection */}

      <div className="mt-4">
        <p className="text-xs font-semibold text-green-300 mb-2">Available drugs</p>
        <div className="flex flex-wrap gap-2">
          {SUPPORTED_DRUGS.map((drug) => {
            const isSelected = normalize(inputText.split(',')).includes(drug)
            return (
              <button
                key={drug}
                onClick={() => handleDrugClick(drug)}
                className={`px-3 py-1 text-sm font-medium rounded-full transition-colors ${
                  isSelected
                    ? 'bg-green-500 text-white'
                    : 'bg-green-500/20 text-green-200 hover:bg-green-500/30 border border-green-400/50'
                }`}
              >
                {drug}
              </button>
            )
          })}
        </div>
      </div>

      {error ? (
        <p className="mt-3 text-sm text-red-400 font-semibold">{error}</p>
      ) : (
        <p className="mt-3 text-xs text-green-300 font-medium">Supported: {SUPPORTED_DRUGS.join(', ')}</p>
      )}
    </div>
  )
}
