'use client'

import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'

interface FileUploadProps {
  file: File | null
  onFileSelect: (file: File | null) => void
  maxSize: number
}

export default function FileUpload({ file, onFileSelect, maxSize }: FileUploadProps) {
  const [error, setError] = useState<string | null>(null)

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    setError(null)

    if (rejectedFiles.length > 0) {
      const rejection = rejectedFiles[0]
      if (rejection.errors.some((e: any) => e.code === 'file-too-large')) {
        setError(`File size exceeds ${maxSize / 1024 / 1024} MB limit`)
      } else if (rejection.errors.some((e: any) => e.code === 'file-invalid-type')) {
        setError('Invalid file type. Please upload a .vcf file')
      } else {
        setError('File upload failed')
      }
      return
    }

    if (acceptedFiles.length > 0) {
      const selectedFile = acceptedFiles[0]
      if (selectedFile.size > maxSize) {
        setError(`File size exceeds ${maxSize / 1024 / 1024} MB limit`)
        return
      }
      onFileSelect(selectedFile)
    }
  }, [maxSize, onFileSelect])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/vcf': ['.vcf'],
      'text/plain': ['.vcf'],
    },
    maxSize,
    multiple: false,
  })

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB'
    return (bytes / 1024 / 1024).toFixed(2) + ' MB'
  }

  return (
    <div>
      <label className="block text-sm font-semibold text-white mb-3">
        VCF File Upload
      </label>
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive
            ? 'border-green-400 bg-green-500/10'
            : 'border-green-400/50 hover:border-green-300'
        }`}
      >
        <input {...getInputProps()} />
        {file ? (
          <div className="space-y-2">
            <div className="text-green-300 font-bold text-lg">File selected</div>
            <div className="text-sm text-green-200 font-medium">
              {file.name} ({formatFileSize(file.size)})
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation()
                onFileSelect(null)
              }}
              className="text-sm text-red-400 hover:text-red-300 font-semibold mt-2"
            >
              Remove file
            </button>
          </div>
        ) : (
          <div>
            <p className="text-green-200 font-medium mb-2">
              {isDragActive
                ? 'Drop the VCF file here'
                : 'Drag & drop a VCF file here, or click to select'}
            </p>
            <p className="text-xs text-green-300/70">
              Maximum file size: {maxSize / 1024 / 1024} MB
            </p>
          </div>
        )}
      </div>
      {error && (
        <div className="mt-2 text-sm text-red-400 font-semibold">{error}</div>
      )}
    </div>
  )
}
