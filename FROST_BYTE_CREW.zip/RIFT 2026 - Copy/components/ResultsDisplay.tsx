'use client'

import { useState } from 'react'
import { AnalysisResult } from '@/types'

interface ResultsDisplayProps {
  results: AnalysisResult | AnalysisResult[]
}

export default function ResultsDisplay({ results }: ResultsDisplayProps) {
  const resultsArray = Array.isArray(results) ? results : [results]
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['pgx_0', 'clinical_0', 'llm_0']))

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections)
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId)
    } else {
      newExpanded.add(sectionId)
    }
    setExpandedSections(newExpanded)
  }

  const getRiskColors = (riskLabel: string) => {
    const risk = riskLabel.toUpperCase()
    if (risk === 'SAFE') {
      return { bg: 'from-green-500/20 to-emerald-500/20', border: 'border-green-400/50', text: 'text-green-100', label: 'SAFE' }
    }
    if (risk === 'ADJUST DOSAGE') {
      return { bg: 'from-yellow-500/20 to-amber-500/20', border: 'border-yellow-400/50', text: 'text-yellow-100', label: 'ADJUST' }
    }
    if (risk === 'TOXIC' || risk === 'INEFFECTIVE') {
      return { bg: 'from-red-500/20 to-pink-500/20', border: 'border-red-400/50', text: 'text-red-100', label: 'CRITICAL' }
    }
    return { bg: 'from-gray-500/20 to-slate-500/20', border: 'border-gray-400/50', text: 'text-gray-100', label: 'UNKNOWN' }
  }

  const getSeverityBadge = (severity: string) => {
    const sev = severity.toLowerCase()
    if (sev === 'critical') return { bg: 'bg-red-600', label: 'CRITICAL' }
    if (sev === 'high') return { bg: 'bg-red-500', label: 'HIGH' }
    if (sev === 'moderate') return { bg: 'bg-yellow-500', label: 'MODERATE' }
    if (sev === 'low') return { bg: 'bg-green-500', label: 'LOW' }
    return { bg: 'bg-gray-500', label: 'UNKNOWN' }
  }

  const downloadJSON = (result: AnalysisResult, index: number) => {
    const dataStr = JSON.stringify(result, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `pharmaguard_result_${result.drug}_${index + 1}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const copyToClipboard = (result: AnalysisResult) => {
    navigator.clipboard.writeText(JSON.stringify(result, null, 2)).then(() => {
      alert('JSON copied to clipboard')
    })
  }

  return (
    <div className="space-y-6">
      {resultsArray.map((result, index) => {
        const riskColors = getRiskColors(result.risk_assessment.risk_label)
        const severityBadge = getSeverityBadge(result.risk_assessment.severity)

        return (
          <div key={index} className="bg-white/5 backdrop-blur-md rounded-2xl shadow-2xl border border-white/10 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-6 py-4 border-b border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">R</span>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">{result.drug} Analysis</h2>
                    <p className="text-xs text-gray-400 mt-1">{result.patient_id} • {new Date(result.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => downloadJSON(result, index)} className="px-4 py-2 bg-green-500/30 hover:bg-green-500/50 text-green-200 rounded-lg transition border border-green-400/30 font-semibold text-sm">Download JSON</button>
                  <button onClick={() => copyToClipboard(result)} className="px-4 py-2 bg-emerald-500/30 hover:bg-emerald-500/50 text-emerald-200 rounded-lg transition border border-emerald-400/30 font-semibold text-sm">Copy JSON</button>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Risk Assessment */}
              <div className={`bg-gradient-to-br ${riskColors.bg} border-2 ${riskColors.border} rounded-xl p-6`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div>
                      <h3 className={`text-3xl font-bold ${riskColors.text}`}>{result.risk_assessment.risk_label}</h3>
                      <p className="text-sm text-gray-300 mt-1">Risk Assessment Status</p>
                    </div>
                  </div>
                  <div className={`${severityBadge.bg} text-white px-4 py-2 rounded-lg font-bold text-sm`}>{severityBadge.label}</div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                    <p className="text-gray-400 text-xs">Confidence Score</p>
                    <p className="text-white font-bold text-xl mt-1">{(result.risk_assessment.confidence_score * 100).toFixed(1)}%</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                    <p className="text-gray-400 text-xs">Risk Level</p>
                    <p className="text-white font-bold text-xl mt-1">{result.risk_assessment.severity}</p>
                  </div>
                </div>
              </div>

              {/* Pharmacogenomic Profile */}
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <button onClick={() => toggleSection(`pgx_${index}`)} className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-green-500/20 to-emerald-500/20 hover:from-green-500/30 hover:to-emerald-500/30">
                  <h3 className="font-bold text-lg text-green-200">Pharmacogenomic Profile</h3>
                  <span className="text-2xl text-green-400">{expandedSections.has(`pgx_${index}`) ? '−' : '+'}</span>
                </button>
                {expandedSections.has(`pgx_${index}`) && (
                  <div className="p-4 space-y-3 bg-gradient-to-b from-green-500/10 to-transparent">
                    <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <p className="text-gray-400 text-xs mb-1">Primary Gene</p>
                      <p className="text-white font-mono font-bold text-lg">{result.pharmacogenomic_profile.primary_gene}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                        <p className="text-gray-400 text-xs mb-1">Diplotype</p>
                        <p className="text-white font-mono">{result.pharmacogenomic_profile.diplotype}</p>
                      </div>
                      <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                        <p className="text-gray-400 text-xs mb-1">Phenotype</p>
                        <p className="text-white font-mono">{result.pharmacogenomic_profile.phenotype}</p>
                      </div>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <p className="text-gray-400 text-xs mb-2">Detected Variants</p>
                      {result.pharmacogenomic_profile.detected_variants.length > 0 ? (
                        <div className="space-y-2">
                          {result.pharmacogenomic_profile.detected_variants.map((variant, vIdx) => (
                            <div key={vIdx} className="bg-white/5 rounded p-2 border border-white/5">
                              <p className="text-white font-mono text-sm">{variant.rsid} ({variant.gene})</p>
                              {variant.star_allele && <p className="text-green-300 text-xs mt-1">{variant.star_allele}</p>}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm">No variants detected</p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Clinical Recommendation */}
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <button onClick={() => toggleSection(`clinical_${index}`)} className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30">
                  <h3 className="font-bold text-lg text-emerald-200">Clinical Recommendation</h3>
                  <span className="text-2xl text-emerald-400">{expandedSections.has(`clinical_${index}`) ? '−' : '+'}</span>
                </button>
                {expandedSections.has(`clinical_${index}`) && (
                  <div className="p-4 space-y-3 bg-gradient-to-b from-emerald-500/10 to-transparent">
                    <div className="bg-white/5 rounded-lg p-4 border border-emerald-400/30">
                      <p className="text-emerald-200 font-bold text-lg mb-2">{result.clinical_recommendation.action}</p>
                      <div className="space-y-2 text-sm text-gray-300">
                        {result.clinical_recommendation.dosing_adjustment && <p><span className="text-emerald-300 font-semibold">Dosing:</span> {result.clinical_recommendation.dosing_adjustment}</p>}
                        {result.clinical_recommendation.monitoring && <p><span className="text-emerald-300 font-semibold">Monitoring:</span> {result.clinical_recommendation.monitoring}</p>}
                        {result.clinical_recommendation.alternative_drugs && <p><span className="text-emerald-300 font-semibold">Alternatives:</span> {result.clinical_recommendation.alternative_drugs.join(', ')}</p>}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* LLM Explanation */}
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <button onClick={() => toggleSection(`llm_${index}`)} className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-teal-500/20 to-green-500/20 hover:from-teal-500/30 hover:to-green-500/30">
                  <h3 className="font-bold text-lg text-teal-200">Clinical Explanation</h3>
                  <span className="text-2xl text-teal-400">{expandedSections.has(`llm_${index}`) ? '−' : '+'}</span>
                </button>
                {expandedSections.has(`llm_${index}`) && (
                  <div className="p-4 space-y-3 bg-gradient-to-b from-teal-500/10 to-transparent">
                    <div className="bg-white/5 rounded-lg p-4 border border-teal-400/30">
                      <p className="text-gray-200 leading-relaxed">{result.llm_generated_explanation.summary}</p>
                      {result.llm_generated_explanation.variant_citations && result.llm_generated_explanation.variant_citations.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-teal-400/30">
                          <p className="text-teal-300 text-xs font-semibold mb-2">Citations:</p>
                          <p className="text-gray-300 text-xs">{result.llm_generated_explanation.variant_citations.join(', ')}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Quality Metrics */}
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-gray-400 text-xs font-semibold mb-2">Quality Metrics</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-300">
                  <p>VCF: {result.quality_metrics.vcf_parsing_success ? 'Success' : 'Failed'}</p>
                  <p>Variants: {result.quality_metrics.variants_analyzed}</p>
                  <p>Pharmacogenomic: {result.quality_metrics.pgx_variants_found}</p>
                  <p>Coverage: {result.quality_metrics.coverage_quality || 'Good'}</p>
                </div>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
