import type { Metadata } from 'next'
import './globals.css'
import { AuthProvider } from './auth-context'

export const metadata: Metadata = {
  title: 'PharmaGuard - Pharmacogenomic Risk Assessment',
  description: 'Analyze patient genetic data and predict personalized pharmacogenomic risks',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-gray-900">
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  )
}
