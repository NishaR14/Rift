'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/app/auth-context'
import FileUpload from '@/components/FileUpload'
import DrugInput from '@/components/DrugInput'
import ResultsDisplay from '@/components/ResultsDisplay'
import { useState } from 'react'
import { AnalysisResult } from '@/types'

export default function DashboardPage() {
  const router = useRouter()
  const { user, token, logout, isLoading, isAuthenticated } = useAuth()
  const [vcfFile, setVcfFile] = useState<File | null>(null)
  const [drugs, setDrugs] = useState<string>('')
  const [results, setResults] = useState<AnalysisResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login')
    }
  }, [isAuthenticated, isLoading, router])

  const handleAnalyze = async () => {
    if (!vcfFile) {
      setError('Please upload a VCF file')
      return
    }

    if (!drugs.trim()) {
      setError('Please enter at least one drug name')
      return
    }

    setLoading(true)
    setError(null)
    setResults(null)

    try {
      const formData = new FormData()
      formData.append('vcf_file', vcfFile)
      formData.append('drugs', drugs)

      const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000'
      const response = await fetch(`${backendUrl}/api/analyze`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Analysis failed')
      }

      const data = await response.json()
      setResults(data.results)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    logout()
    router.push('/login')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-green-400"></div>
          <p className="mt-4 text-green-300 font-medium">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-green-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse"></div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse animation-delay-2000"></div>
      {/* Navigation Bar */}
      <nav className="bg-white/5 backdrop-blur-md border-b border-white/10 sticky top-0 z-40">
        <div className="w-full px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">R</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">PharmaGuard</h1>
                <p className="text-xs text-green-300">Pharmacogenomic Analysis</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {user && (
              <>
                <div className="text-right">
                  <p className="text-xs text-green-300">Welcome</p>
                  <p className="font-bold text-white">{user.email}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-bold py-2 px-6 rounded-lg transition transform hover:scale-105"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 h-full">
          {/* Input Section - Left Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl shadow-2xl p-6 border border-white/10 hover:border-white/20 transition">
              <h2 className="text-xl font-bold text-white mb-6">Setup Analysis</h2>
              
              <div className="space-y-5">
                <FileUpload onFileSelect={setVcfFile} file={vcfFile} maxSize={5 * 1024 * 1024} />
                <DrugInput value={drugs} onChange={setDrugs} />
                
                <button
                  onClick={handleAnalyze}
                  disabled={loading || !vcfFile}
                  className="w-full bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 hover:from-green-400 hover:via-emerald-400 hover:to-teal-400 disabled:from-gray-600 disabled:via-gray-600 disabled:to-gray-600 text-white font-bold py-4 px-4 rounded-xl transition transform hover:scale-105 shadow-lg disabled:cursor-not-allowed text-lg"
                >
                  {loading ? 'Analyzing...' : 'Analyze'}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/20 backdrop-blur-md border border-red-400/50 rounded-xl p-4">
                <p className="text-red-300 font-semibold">Error</p>
                <p className="text-red-200 text-sm mt-1">{error}</p>
              </div>
            )}
          </div>

          {/* Results Section - Right Content */}
          <div className="lg:col-span-3">
            {results ? (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl shadow-2xl p-8 border border-white/10 hover:border-white/20 transition">
                <ResultsDisplay results={results} />
              </div>
            ) : (
              <div className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-16 text-center border border-white/10 hover:border-white/20 transition h-full flex items-center justify-center">
                <div>
                  <p className="text-gray-300 text-xl mb-4">Upload a VCF file to begin analysis</p>
                  <p className="text-gray-400 text-sm">Select your genetic data and drug profile to see personalized risk assessment</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
